package com.indiantrademart.entity;

public enum Role {
    ROLE_USER,
    ROLE_VENDOR,
    ROLE_ADMIN
}
